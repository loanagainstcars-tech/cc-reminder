package com.example.customerreminder.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface CustomerDao {
    @Query("""
        SELECT * FROM customers
        ORDER BY
          CASE WHEN reminderAt IS NULL THEN 1 ELSE 0 END,
          reminderAt ASC
    """)
    fun getAllSorted(): LiveData<List<Customer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(customer: Customer): Long

    @Update
    suspend fun update(customer: Customer)

    @Delete
    suspend fun delete(customer: Customer)

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getById(id: Int): Customer?
}