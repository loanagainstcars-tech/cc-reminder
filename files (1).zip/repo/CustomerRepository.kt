package com.example.customerreminder.repo

import android.content.Context
import com.example.customerreminder.data.AppDatabase
import com.example.customerreminder.data.Customer

class CustomerRepository(context: Context) {
    private val dao = AppDatabase.getInstance(context).customerDao()
    val allCustomers = dao.getAllSorted()

    suspend fun insert(customer: Customer): Long = dao.insert(customer)
    suspend fun update(customer: Customer) = dao.update(customer)
    suspend fun delete(customer: Customer) = dao.delete(customer)
    suspend fun getById(id: Int) = dao.getById(id)
}