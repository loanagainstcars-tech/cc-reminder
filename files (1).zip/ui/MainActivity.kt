package com.example.customerreminder.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.customerreminder.databinding.ActivityMainBinding
import com.example.customerreminder.notification.AlarmScheduler
import com.example.customerreminder.viewmodel.CustomerViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val vm: CustomerViewModel by viewModels()
    private lateinit var adapter: CustomerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = CustomerAdapter(
            onEdit = { customer ->
                val i = Intent(this, AddEditActivity::class.java)
                i.putExtra("customer_id", customer.id)
                startActivity(i)
            },
            onDelete = { customer ->
                vm.delete(customer) {
                    // cancel scheduled alarm if any
                    customer.reminderAt?.let { AlarmScheduler.cancel(this, customer.id) }
                }
            }
        )

        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        vm.customers.observe(this) { list ->
            adapter.submitList(list)
            binding.emptyView.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AddEditActivity::class.java))
        }
    }
}