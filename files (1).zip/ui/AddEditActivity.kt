package com.example.customerreminder.ui

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.customerreminder.data.Customer
import com.example.customerreminder.databinding.ActivityAddEditBinding
import com.example.customerreminder.notification.AlarmScheduler
import com.example.customerreminder.viewmodel.CustomerViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class AddEditActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddEditBinding
    private val vm: CustomerViewModel by viewModels()
    private var editingId: Int? = null
    private var pickedDateMillis: Long? = null // date at midnight

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        editingId = intent.getIntExtra("customer_id", -1).takeIf { it != -1 }
        if (editingId != null) {
            // load existing
            CoroutineScope(Dispatchers.IO).launch {
                val c = vm.getApplication<Application>().let { // quick access to repo through viewmodel not ideal but ok
                    // better to expose getById in viewmodel; for brevity call repository:
                    // We'll use vmScope to call repo - but here simple approach:
                }
            }
            // For simplicity, retrieve using repository pattern directly:
            CoroutineScope(Dispatchers.IO).launch {
                val repo = com.example.customerreminder.repo.CustomerRepository(applicationContext)
                val cust = repo.getById(editingId!!)
                cust?.let {
                    runOnUiThread {
                        binding.etName.setText(it.name)
                        binding.etPhone.setText(it.phone)
                        binding.etAddress.setText(it.address)
                        binding.etRemark.setText(it.remark)
                        pickedDateMillis = it.reminderAt
                        binding.btnPickDate.text = if (pickedDateMillis != null) {
                            java.text.SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(pickedDateMillis!!))
                        } else "Pick Reminder Date"
                    }
                }
            }
        }

        binding.btnPickDate.setOnClickListener {
            val now = Calendar.getInstance()
            val dp = DatePickerDialog(
                this,
                { _, y, m, d ->
                    val cal = Calendar.getInstance().apply {
                        set(Calendar.YEAR, y)
                        set(Calendar.MONTH, m)
                        set(Calendar.DAY_OF_MONTH, d)
                        // set to midnight so we can later set 11:00
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    pickedDateMillis = cal.timeInMillis
                    binding.btnPickDate.text = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(pickedDateMillis!!))
                },
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH),
                now.get(Calendar.DAY_OF_MONTH)
            )
            dp.show()
        }

        binding.btnSave.setOnClickListener {
            val name = binding.etName.text.toString().trim()
            val phone = binding.etPhone.text.toString().trim()
            val address = binding.etAddress.text.toString().trim()
            val remark = binding.etRemark.text.toString().trim().ifEmpty { null }

            if (name.isEmpty() || phone.isEmpty()) {
                android.widget.Toast.makeText(this, "Name aur Phone zaroori hai", android.widget.Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // convert pickedDateMillis (midnight) to 11:00 AM of that day
            val reminderAtAdjusted = pickedDateMillis?.let {
                Calendar.getInstance().apply {
                    timeInMillis = it
                    set(Calendar.HOUR_OF_DAY, 11)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
            }

            val customer = if (editingId != null) {
                Customer(id = editingId!!, name = name, phone = phone, address = address, remark = remark, reminderAt = reminderAtAdjusted)
            } else {
                Customer(name = name, phone = phone, address = address, remark = remark, reminderAt = reminderAtAdjusted)
            }

            // Save via viewmodel
            if (editingId != null) {
                vm.update(customer) {
                    // Cancel existing alarm then schedule new if needed
                    AlarmScheduler.cancel(this, customer.id)
                    customer.reminderAt?.let { AlarmScheduler.schedule(this, customer.id, it, customer.name) }
                    finish()
                }
            } else {
                vm.insert(customer) { newId ->
                    // schedule alarm for newId
                    if (customer.reminderAt != null) {
                        AlarmScheduler.schedule(this, newId.toInt(), customer.reminderAt, customer.name)
                    }
                    finish()
                }
            }
        }

        binding.btnDelete.setOnClickListener {
            if (editingId != null) {
                // delete
                CoroutineScope(Dispatchers.IO).launch {
                    val repo = com.example.customerreminder.repo.CustomerRepository(applicationContext)
                    val cust = repo.getById(editingId!!)
                    cust?.let {
                        repo.delete(it)
                        // cancel alarm
                        AlarmScheduler.cancel(this@AddEditActivity, it.id)
                    }
                    runOnUiThread { finish() }
                }
            } else finish()
        }
    }
}