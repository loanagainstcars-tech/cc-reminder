package com.example.customerreminder.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.customerreminder.data.Customer
import com.example.customerreminder.repo.CustomerRepository
import kotlinx.coroutines.launch

class CustomerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = CustomerRepository(app)
    val customers = repo.allCustomers

    fun insert(customer: Customer, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repo.insert(customer)
            onDone(id)
        }
    }

    fun update(customer: Customer, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repo.update(customer)
            onDone?.invoke()
        }
    }

    fun delete(customer: Customer, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repo.delete(customer)
            onDone?.invoke()
        }
    }
}