package com.ccreminder.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.ccreminder.data.Customer
import com.ccreminder.databinding.ItemCustomerBinding
import java.text.SimpleDateFormat
import java.util.*

class CustomerAdapter(
    private val onEdit: (Customer) -> Unit,
    private val onDelete: (Customer) -> Unit
) : ListAdapter<Customer, CustomerAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemCustomerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = getItem(position)
        holder.bind(c)
    }

    inner class VH(private val b: ItemCustomerBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(c: Customer) {
            b.tvName.text = c.name
            b.tvPhone.text = c.phone
            b.tvAddress.text = c.address
            b.tvRemark.text = c.remark ?: ""
            b.btnEdit.setOnClickListener { onEdit(c) }
            b.btnDelete.setOnClickListener { onDelete(c) }
            b.tvReminder.text = c.reminderAt?.let {
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                sdf.format(Date(it))
            } ?: "-"
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Customer>() {
            override fun areItemsTheSame(oldItem: Customer, newItem: Customer) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Customer, newItem: Customer) = oldItem == newItem
        }
    }
}