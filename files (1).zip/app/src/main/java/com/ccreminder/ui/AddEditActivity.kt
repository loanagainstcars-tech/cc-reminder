package com.ccreminder.ui

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.ccreminder.data.Customer
import com.ccreminder.databinding.ActivityAddEditBinding
import com.ccreminder.notification.AlarmScheduler
import com.ccreminder.viewmodel.CustomerViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class AddEditActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddEditBinding
    private val vm: CustomerViewModel by viewModels()
    private var editingId: Int? = null
    private var pickedDateMillis: Long? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        editingId = intent.getIntExtra("customer_id", -1).takeIf { it != -1 }
        if (editingId != null) {
            CoroutineScope(Dispatchers.IO).launch {
                val repo = com.ccreminder.repo.CustomerRepository(applicationContext)
                val cust = repo.getById(editingId!!)
                cust?.let {
                    runOnUiThread {
                        binding.etName.setText(it.name)
                        binding.etPhone.setText(it.phone)
                        binding.etAddress.setText(it.address)
                        binding.etRemark.setText(it.remark)
                        pickedDateMillis = it.reminderAt
                        binding.btnPickDate.text = it.reminderAt?.let { d ->
                            java.text.SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(d))
                        } ?: getString(com.ccreminder.R.string.pick_reminder)
                    }
                }
            }
        } else {
            binding.btnPickDate.text = getString(com.ccreminder.R.string.pick_reminder)
        }

        binding.btnPickDate.setOnClickListener {
            val now = Calendar.getInstance()
            val dp = DatePickerDialog(
                this,
                { _, y, m, d ->
                    val cal = Calendar.getInstance().apply {
                        set(Calendar.YEAR, y)
                        set(Calendar.MONTH, m)
                        set(Calendar.DAY_OF_MONTH, d)
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    pickedDateMillis = cal.timeInMillis
                    binding.btnPickDate.text = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(pickedDateMillis!!))
                },
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH),
                now.get(Calendar.DAY_OF_MONTH)
            )
            dp.show()
        }

        binding.btnSave.setOnClickListener {
            val name = binding.etName.text.toString().trim()
            val phone = binding.etPhone.text.toString().trim()
            val address = binding.etAddress.text.toString().trim()
            val remark = binding.etRemark.text.toString().trim().ifEmpty { null }

            if (name.isEmpty() || phone.isEmpty()) {
                android.widget.Toast.makeText(this, "Name aur Phone zaroori hai", android.widget.Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val reminderAtAdjusted = pickedDateMillis?.let {
                Calendar.getInstance().apply {
                    timeInMillis = it
                    set(Calendar.HOUR_OF_DAY, 11)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
            }

            val customer = if (editingId != null) {
                Customer(id = editingId!!, name = name, phone = phone, address = address, remark = remark, reminderAt = reminderAtAdjusted)
            } else {
                Customer(name = name, phone = phone, address = address, remark = remark, reminderAt = reminderAtAdjusted)
            }

            if (editingId != null) {
                vm.update(customer) {
                    AlarmScheduler.cancel(this, customer.id)
                    customer.reminderAt?.let { AlarmScheduler.schedule(this, customer.id, it, customer.name) }
                    finish()
                }
            } else {
                vm.insert(customer) { newId ->
                    if (customer.reminderAt != null) {
                        AlarmScheduler.schedule(this, newId.toInt(), customer.reminderAt, customer.name)
                    }
                    finish()
                }
            }
        }

        binding.btnDelete.setOnClickListener {
            if (editingId != null) {
                CoroutineScope(Dispatchers.IO).launch {
                    val repo = com.ccreminder.repo.CustomerRepository(applicationContext)
                    val cust = repo.getById(editingId!!)
                    cust?.let {
                        repo.delete(it)
                        AlarmScheduler.cancel(this@AddEditActivity, it.id)
                    }
                    runOnUiThread { finish() }
                }
            } else finish()
        }
    }
}