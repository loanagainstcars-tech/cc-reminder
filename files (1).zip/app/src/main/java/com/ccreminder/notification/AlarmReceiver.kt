package com.ccreminder.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("customer_id", 0)
        val title = intent.getStringExtra("title") ?: "Reminder"
        NotificationHelper.createChannel(context)
        val n = NotificationCompat.Builder(context, NotificationHelper.CHANNEL_ID)
            .setContentTitle("Follow up: $title")
            .setContentText("Customer follow up scheduled for today at 11:00 AM")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
            .build()

        with(NotificationManagerCompat.from(context)) {
            notify(1000 + id, n)
        }
    }
}