package com.ccreminder.repo

import android.content.Context
import com.ccreminder.data.AppDatabase
import com.ccreminder.data.Customer

class CustomerRepository(context: Context) {
    private val dao = AppDatabase.getInstance(context).customerDao()
    val allCustomers = dao.getAllSorted()

    suspend fun insert(customer: Customer): Long = dao.insert(customer)
    suspend fun update(customer: Customer) = dao.update(customer)
    suspend fun delete(customer: Customer) = dao.delete(customer)
    suspend fun getById(id: Int) = dao.getById(id)
}